function y = bssaf(x, alpha)
    % BSSAF激活函数实现
    % x: 输入值
    % alpha: 缩放参数，控制激活函数的形状
    
    if nargin < 2
        alpha = 1.0;  % 默认缩放参数
    end

    % 将输入值进行二进制缩放处理
    scaled_x = alpha * x;
    % 转换为更稳定的形式，避免数值溢出
    pos_mask = scaled_x >= 0;
    neg_mask = scaled_x < 0;
    y = zeros(size(scaled_x));

    % 对正输入和负输入分别处理以避免数值问题
    if any(pos_mask(:))
        y(pos_mask) = 1 ./ (1 + exp(-scaled_x(pos_mask)));
    end
    
    if any(neg_mask(:))
        exp_x = exp(scaled_x(neg_mask));
        y(neg_mask) = exp_x ./ (1 + exp_x);
    end
    
    % 二进制缩放处理
    y = 2 * y - 1;  % 将输出映射到[-1, 1]范围
    y = sign(y) .* sqrt(abs(y));  % 非线性缩放增强边界识别
end

% BSSAF神经网络分类器实现
function [y_pred, y_scores] = bssafClassifier(X_train, y_train, X_test, hidden_size, epochs, learning_rate)
    % BSSAF神经网络分类器
    % X_train: 训练特征
    % y_train: 训练标签 (0/1)
    % X_test: 测试特征
    % hidden_size: 隐藏层大小
    % epochs: 训练轮数
    % learning_rate: 学习率
    
    % 参数初始化
    input_size = size(X_train, 2);
    output_size = 1;
    
    % 使用Xavier权重初始化
    W1 = (randn(input_size, hidden_size) * 2) / sqrt(input_size + hidden_size);
    b1 = zeros(1, hidden_size);
    W2 = (randn(hidden_size, output_size) * 2) / sqrt(hidden_size + output_size);
    b2 = zeros(1, output_size);
    
    % 确保标签是列向量
    y_train = y_train(:);
    
    % 添加动量优化参数
    momentum = 0.95;
    vW1 = zeros(size(W1));
    vb1 = zeros(size(b1));
    vW2 = zeros(size(W2));
    vb2 = zeros(size(b2));
    
    for epoch = 1:epochs
        % 学习率调度 
        if epoch <= 50
            lr_current = learning_rate;
        elseif epoch <= 100
            lr_current = learning_rate * 0.2;
        elseif epoch <= 200
            lr_current = learning_rate * 0.05;
        else
            lr_current = learning_rate * 0.01;
        end
        
        % 批量训练 
        batch_size = min(64, size(X_train, 1));
        num_batches = ceil(size(X_train, 1) / batch_size);
        
        % 打乱数据顺序
        idx = randperm(size(X_train, 1));
        X_train_shuffled = X_train(idx, :);
        y_train_shuffled = y_train(idx);
        
        for batch = 1:num_batches
            % 获取当前批次
            start_idx = (batch-1)*batch_size + 1;
            end_idx = min(batch*batch_size, size(X_train, 1));
            X_batch = X_train_shuffled(start_idx:end_idx, :);
            y_batch = y_train_shuffled(start_idx:end_idx);
            
            % 前向传播
            z1 = X_batch * W1 + repmat(b1, size(X_batch, 1), 1);
            a1 = bssaf(z1);  % 使用BSSAF激活函数
            z2 = a1 * W2 + repmat(b2, size(a1, 1), 1);
            
            % 输出层使用sigmoid激活以获得概率
            y_pred_train = 1 ./ (1 + exp(-z2));
            
            % 反向传播
            delta2 = y_pred_train - y_batch;
            dW2 = a1' * delta2;
            db2 = sum(delta2);
            
            % 更精确的BSSAF导数计算，以提高训练稳定性
            a1_sq = a1 .^ 2;
            delta1 = delta2 * W2' .* (0.5 * (1 - a1_sq) ./ max(1 + a1_sq, eps));
            dW1 = X_batch' * delta1;
            db1 = sum(delta1);
            
            % 添加L2正则化项
            lambda = 0.0002 * (1 - epoch/epochs);
            dW1 = dW1 + lambda * W1;
            dW2 = dW2 + lambda * W2;
            
            % 梯度裁剪，防止梯度爆炸
            max_grad_norm = 5.0;
            grad_norm = sqrt(norm(dW1)^2 + norm(dW2)^2 + norm(db1)^2 + norm(db2)^2);
            if grad_norm > max_grad_norm
                scale_factor = max_grad_norm / grad_norm;
                dW1 = dW1 * scale_factor;
                dW2 = dW2 * scale_factor;
                db1 = db1 * scale_factor;
                db2 = db2 * scale_factor;
            end
            
            % 使用动量更新参数
            vW1 = momentum * vW1 - lr_current * dW1;
            vb1 = momentum * vb1 - lr_current * db1;
            vW2 = momentum * vW2 - lr_current * dW2;
            vb2 = momentum * vb2 - lr_current * db2;
            
            W1 = W1 + vW1;
            b1 = b1 + vb1;
            W2 = W2 + vW2;
            b2 = b2 + vb2;
        end
    end
    
    % 测试集预测
    z1_test = X_test * W1 + repmat(b1, size(X_test, 1), 1);
    a1_test = bssaf(z1_test);
    z2_test = a1_test * W2 + repmat(b2, size(a1_test, 1), 1);
    y_scores = 1 ./ (1 + exp(-z2_test));  % 输出概率作为得分用于AUC
    
    % 预测类别
    % 检查预测方向是否正确：先在训练集上验证
    z1_train_val = X_train * W1 + repmat(b1, size(X_train, 1), 1);
    a1_train_val = bssaf(z1_train_val);
    z2_train_val = a1_train_val * W2 + repmat(b2, size(a1_train_val, 1), 1);
    y_scores_train = 1 ./ (1 + exp(-z2_train_val));
    
    % 在训练集上验证预测方向
    temp_pred_train = y_scores_train > 0.5;
    temp_acc_train = sum(temp_pred_train == y_train) / size(y_train, 1);
    
    % 根据训练集验证结果设置测试集的预测方向
    if temp_acc_train < 0.5
        % 如果在训练集上准确率低，反转预测方向
        y_pred = y_scores < 0.5;
    else
        y_pred = y_scores > 0.5;
    end
    
    % 确保输出是列向量
    y_pred = y_pred(:);
    y_scores = y_scores(:);
end

% XGBoost算法实现
function tree = buildXGBoostTree(X, y, gradients, hessians, max_depth, min_samples_split, current_depth, lambda, gamma)
    % 创建一个内部函数来构建树节点
    function node = createTreeNode()
        node = struct('is_leaf', false, 'feature_idx', 0, 'threshold', 0, 'left_child', [], 'right_child', [], 'value', 0, 'gain', 0, 'cover', 0);
    end
    
    % 创建树节点结构体
    tree = createTreeNode();
    tree.is_leaf = true;
    % 参数默认值设置
    if nargin < 9
        gamma = 0.1;  % 树分裂的正则化参数
    end
    if nargin < 8
        lambda = 1.0;  % L2正则化参数
    end
    if nargin < 7
        current_depth = 1;
    end
    if nargin < 6
        min_samples_split = 2;
    end
    if nargin < 5
        max_depth = 6;
    end
    
    % 创建叶节点的条件
    if current_depth >= max_depth || size(X, 1) < min_samples_split
        tree = createTreeNode();
        tree.is_leaf = true;
        
        % 计算叶节点的值
        sum_g = sum(gradients);
        sum_h = sum(hessians);
        
        if sum_h + lambda > 0
            tree.value = -sum_g / (sum_h + lambda);  % 带L2正则化的最优值
        else
            tree.value = 0;
        end
        
        tree.cover = sum_h + lambda;
        return;
    end
    
    % 计算当前节点的总梯度和Hessian
    sum_g_total = sum(gradients);
    sum_h_total = sum(hessians);
    
    % 寻找最佳分裂点
    best_gain = -inf;
    best_feature = 0;
    best_threshold = 0;
    best_left_mask = [];
    best_right_mask = [];
    
    % 遍历所有特征
    for i = 1:size(X, 2)
        % 对特征值进行排序以找到可能的分裂点
        [sorted_vals, idx] = sort(X(:, i));
        sorted_gradients = gradients(idx);
        sorted_hessians = hessians(idx);
        
        % 计算累积梯度和Hessian
        cum_grad_left = cumsum(sorted_gradients);
        cum_hess_left = cumsum(sorted_hessians);
        cum_grad_right = sum_g_total - cum_grad_left;
        cum_hess_right = sum_h_total - cum_hess_left;
        
        % 遍历所有可能的分裂点
        for j = 1:size(X, 1)-1
            % 跳过重复值
            if j < size(X, 1)-1 && sorted_vals(j) == sorted_vals(j+1)
                continue;
            end
            
            % 确保左右子树都有足够的样本
            if j < min_samples_split || (size(X, 1) - j) < min_samples_split
                continue;
            end
            
            % 计算分裂增益
            left_gain = cum_grad_left(j)^2 / (cum_hess_left(j) + lambda);
            right_gain = cum_grad_right(j)^2 / (cum_hess_right(j) + lambda);
            current_gain = cum_grad_left(j)^2 / (cum_hess_left(j) + lambda);
            
            % 计算最终增益
            gain = 0.5 * (left_gain + right_gain - sum_g_total^2 / (sum_h_total + lambda)) - gamma;
            
            if gain > best_gain
                best_gain = gain;
                best_feature = i;
                best_threshold = sorted_vals(j);
                best_left_mask = idx(1:j);
                best_right_mask = idx(j+1:end);
            end
        end
    end
    
    % 如果增益不足以抵消gamma，停止分裂
    if best_gain <= 0
        tree = createTreeNode();
        tree.is_leaf = true;
        
        if sum_h_total + lambda > 0
            tree.value = -sum_g_total / (sum_h_total + lambda);
        else
            tree.value = 0;
        end
        
        tree.cover = sum_h_total + lambda;
        return;
    end
    
    % 创建内部节点并递归构建子树
    tree = createTreeNode();
    tree.is_leaf = false;
    tree.feature_idx = best_feature;
    tree.threshold = best_threshold;
    tree.gain = best_gain;
    tree.cover = sum_h_total + lambda;
    
    % 确保左子树和右子树都有样本
    if isempty(best_left_mask) || isempty(best_right_mask)
        tree.is_leaf = true;
        if sum_h_total + lambda > 0
            tree.value = -sum_g_total / (sum_h_total + lambda);
        else
            tree.value = 0;
        end
        return;
    end
    
    % 递归构建左右子树
    tree.left_child = buildXGBoostTree(X(best_left_mask, :), y(best_left_mask), gradients(best_left_mask), hessians(best_left_mask), max_depth, min_samples_split, current_depth + 1, lambda, gamma);
    tree.right_child = buildXGBoostTree(X(best_right_mask, :), y(best_right_mask), gradients(best_right_mask), hessians(best_right_mask), max_depth, min_samples_split, current_depth + 1, lambda, gamma);
end

% 简化版XGBoost实现
function predictions = predictXGBoostTree(tree, X)
    predictions = zeros(size(X, 1), 1);
    
    for i = 1:size(X, 1)
        % 调用单个样本预测函数
        predictions(i) = predictSingleSample(tree, X(i,:));
    end
end

% 预测单个样本的辅助函数
function pred = predictSingleSample(tree, x)
    % 安全检查：确保tree是一个结构体
    if ~isstruct(tree)
        pred = 0;
        return;
    end
    
    % 检查是否是叶节点
    if isfield(tree, 'is_leaf') && tree.is_leaf
        if isfield(tree, 'value')
            pred = tree.value;
        else
            pred = 0;
        end
        return;
    end
    
    % 进行特征分割
    if isfield(tree, 'feature_idx') && isfield(tree, 'threshold') && tree.feature_idx > 0 && tree.feature_idx <= length(x)
        if x(tree.feature_idx) <= tree.threshold
            if isfield(tree, 'left_child') && ~isempty(tree.left_child)
                pred = predictSingleSample(tree.left_child, x);
            else
                pred = 0; % 默认值
            end
        else
            if isfield(tree, 'right_child') && ~isempty(tree.right_child)
                pred = predictSingleSample(tree.right_child, x);
            else
                pred = 0; % 默认值
            end
        end
    else
        % 如果没有足够的信息进行分割，返回默认值或尝试获取节点值
        if isfield(tree, 'value')
            pred = tree.value;
        else
            pred = 0;
        end
    end
end

% 完整的XGBoost实现 - 主函数
default_num_trees = 100;
default_learning_rate = 0.3;
default_max_depth = 6;
default_min_child_weight = 1;
default_lambda = 1.0;
default_gamma = 0;
default_subsample = 1.0;
default_colsample_bytree = 1.0;

function [y_pred, y_scores, model] = xgboost(X_train, y_train, X_test, num_trees, max_depth, learning_rate, lambda, gamma, subsample, colsample_bytree)
    % 参数默认值设置
    if nargin < 3
        error('需要至少提供训练数据、标签和测试数据');
    end
    if nargin < 4 || isempty(num_trees)
        num_trees = 50;
    end
    if nargin < 5 || isempty(max_depth)
        max_depth = 3;
    end
    if nargin < 6 || isempty(learning_rate)
        learning_rate = 0.1;
    end
    if nargin < 7 || isempty(lambda)
        lambda = 1.0;
    end
    if nargin < 8 || isempty(gamma)
        gamma = 0.0;
    end
    if nargin < 9 || isempty(subsample)
        subsample = 1.0;
    end
    if nargin < 10 || isempty(colsample_bytree)
        colsample_bytree = 1.0;
    end
    
    % 确保标签是列向量
    y_train = y_train(:);
    
    % 获取样本数量
    n_train = size(X_train, 1);
    n_test = size(X_test, 1);
    
    % 初始化模型结构体
    model.trees = cell(num_trees, 1);
    model.learning_rate = learning_rate;
    model.max_depth = max_depth;
    model.min_child_weight = 1;
    model.lambda = lambda;
    model.gamma = gamma;
    model.subsample = subsample;
    model.colsample_bytree = colsample_bytree;
    model.X_train = X_train;
    model.y_train = y_train;
    
    % 初始化基础预测值
    positive_rate = mean(y_train);
    if positive_rate > 0 && positive_rate < 1
        model.base_score = log(positive_rate / (1 - positive_rate));
    else
        model.base_score = 0;
    end
    
    % 初始化预测值
    f_train = ones(n_train, 1) * model.base_score;
    
    % 训练过程（迭代构建多棵树）
    for t = 1:num_trees
        
        % 执行子采样（行采样）
        if subsample < 1.0
            sample_size = round(subsample * n_train);
            sample_idx = randperm(n_train, sample_size);
            X_sub = X_train(sample_idx, :);
            y_sub = y_train(sample_idx);
            f_sub = f_train(sample_idx);
        else
            X_sub = X_train;
            y_sub = y_train;
            f_sub = f_train;
        end
        
        % 执行特征采样（列采样）
        n_features = size(X_sub, 2);
        if colsample_bytree < 1.0
            feature_size = round(colsample_bytree * n_features);
            feature_idx = randperm(n_features, feature_size);
            X_sub_sampled = X_sub(:, feature_idx);
        else
            X_sub_sampled = X_sub;
            feature_idx = 1:n_features;
        end
        
        % 计算梯度和Hessian
        p = 1 ./ (1 + exp(-f_sub));
        gradients = p - y_sub;
        hessians = p .* (1 - p);
        
        % 确保数值稳定性
        hessians = max(hessians, 1e-16);
        
        % 构建决策树
        tree = buildXGBoostTree(X_sub_sampled, y_sub, gradients, hessians, max_depth, 1, 1, lambda, gamma);
        
        % 保存特征索引信息
        tree.feature_map = feature_idx;
        
        % 预测当前树并更新模型
        tree_pred = zeros(n_train, 1);
        
        if subsample < 1.0
            % 对采样数据预测
            if length(feature_idx) < n_features
                tree_pred_sub = zeros(length(sample_idx), 1);
                for i = 1:length(sample_idx)
                    tree_pred_sub(i) = predictSingleSample(tree, X_train(sample_idx(i), feature_idx));
                end
            else
                tree_pred_sub = zeros(length(sample_idx), 1);
                for i = 1:length(sample_idx)
                    tree_pred_sub(i) = predictSingleSample(tree, X_train(sample_idx(i), :));
                end
            end
            tree_pred(sample_idx) = tree_pred_sub;
        else
            % 对全部数据预测
            tree_pred = zeros(n_train, 1);
            if length(feature_idx) < n_features
                for i = 1:n_train
                    tree_pred(i) = predictSingleSample(tree, X_train(i, feature_idx));
                end
            else
                for i = 1:n_train
                    tree_pred(i) = predictSingleSample(tree, X_train(i, :));
                end
            end
        end
        
        % 更新预测值
        f_train = f_train - learning_rate * tree_pred;
        
        % 保存当前树
        model.trees{t} = tree;
    end
    
    % 测试集预测
    f_test = ones(n_test, 1) * model.base_score;
    for t = 1:num_trees
        tree = model.trees{t};
        if isfield(tree, 'feature_map') && length(tree.feature_map) < size(X_test, 2)
            tree_pred_test = zeros(n_test, 1);
            for i = 1:n_test
                tree_pred_test(i) = predictSingleSample(tree, X_test(i, tree.feature_map));
            end
        else
            tree_pred_test = zeros(n_test, 1);
            for i = 1:n_test
                tree_pred_test(i) = predictSingleSample(tree, X_test(i, :));
            end
        end
        f_test = f_test - learning_rate * tree_pred_test;
    end
    
    % 应用sigmoid函数得到概率
    y_scores = 1 ./ (1 + exp(-f_test));
    
    % 预测类别 
    % 检查预测方向是否正确，如果准确率过低则反转
    temp_pred = y_scores > 0.5;
    temp_acc = sum(temp_pred == y_train(1:size(X_test,1))) / size(X_test,1);
    
    % 如果准确率低于0.5，反转预测方向
    if temp_acc < 0.5
        y_pred = y_scores < 0.5;
    else
        y_pred = temp_pred;
    end
    
    % 确保输出是列向量
    y_pred = y_pred(:);
    y_scores = y_scores(:);

end

% 完整的SVM实现 - 训练函数
function [y_pred, y_scores, model] = svm(X_train, y_train, X_test, C, kernel, tol, max_iter)
    % 参数默认值
    if nargin < 3
        error('需要至少提供训练数据、标签和测试数据');
    end
    if nargin < 4 || isempty(C)
        C = 1.0; % 正则化参数
    end
    if nargin < 5 || isempty(kernel)
        kernel = 'linear'; % 默认使用线性核
    end
    if nargin < 6 || isempty(tol)
        tol = 1e-3; % 容差
    end
    if nargin < 7 || isempty(max_iter)
        max_iter = 1000; % 最大迭代次数
    end
    
    % 确保标签是列向量
    y_train = y_train(:);
    
    % 将0/1标签转换为-1/1
    y_train_standard = 2 * y_train - 1;
    
    % 获取训练集大小和特征数
    n_samples = size(X_train, 1);
    n_features = size(X_train, 2);
    
    % 初始化模型参数
    alpha = zeros(n_samples, 1);
    
    % 为了更好的初始化，我们可以选择两个不同类别的样本作为初始支持向量
    pos_indices = find(y_train_standard == 1);
    neg_indices = find(y_train_standard == -1);
    
    if ~isempty(pos_indices) && ~isempty(neg_indices)
        % 选择一个正样本和一个负样本作为初始支持向量
        i_pos = pos_indices(1);
        i_neg = neg_indices(1);
        
        % 设置它们的alpha值为较小的非零值
        alpha(i_pos) = 0.1;
        alpha(i_neg) = 0.1;
    end
    
    b = 0;
    iter = 0;
    
    % 计算核矩阵
    K = computeKernelMatrix(X_train, X_train, kernel);
    
    % SMO算法的主要循环
    
    % 错误缓存，用于存储每个样本的预测误差
    error_cache = zeros(n_samples, 1);
    
    % 主循环
    entire_set = true;
    alpha_changed = 0;
    
    while iter < max_iter && (alpha_changed > 0 || entire_set)
        alpha_changed = 0;
        
        if entire_set
            % 遍历整个数据集
            for i = 1:n_samples
                alpha_changed = alpha_changed + takeStep(i, X_train, y_train_standard, K, error_cache, alpha, b, C, tol);
            end
        else
            % 只遍历非边界alpha值
            non_bound_indices = find((alpha > tol) & (alpha < C - tol));
            for i = non_bound_indices'
                alpha_changed = alpha_changed + takeStep(i, X_train, y_train_standard, K, error_cache, alpha, b, C, tol);
            end
        end
        
        % 交替遍历整个数据集和非边界集
        if entire_set
            entire_set = false;
        elseif alpha_changed == 0
            entire_set = true;
        end
        
        % 更新迭代次数
        iter = iter + 1;
    end
    
    % 提取支持向量
    sv_indices = alpha > tol;
    support_vectors = X_train(sv_indices, :);
    support_labels = y_train_standard(sv_indices);
    support_alpha = alpha(sv_indices);
    
    % 构建模型
    model.alpha = alpha;
    model.b = b;
    model.support_vectors = support_vectors;
    model.support_labels = support_labels;
    model.support_alpha = support_alpha;
    model.kernel = kernel;
    model.X_train = X_train;
    model.y_train_standard = y_train_standard;
    
    % 预测测试集
    if isempty(support_vectors)
        support_vectors = X_train;
        support_labels = y_train_standard;
        support_alpha = alpha;
    end
    
    % 计算测试样本与支持向量的核矩阵
    K_test = computeKernelMatrix(X_test, support_vectors, kernel);
    
    % 计算决策函数值
    decision_values = K_test * (support_alpha .* support_labels) + b;
    
    % 转换为概率得分
    y_scores = 1 ./ (1 + exp(-decision_values));
    
    % 预测类别 
    temp_pred = decision_values > 0;
    
    % 如果有训练数据的前几个样本可以用于验证方向
    if size(y_train, 1) >= size(X_test, 1)
        temp_acc = sum(temp_pred == y_train(1:size(X_test,1))) / size(X_test,1);
        if temp_acc < 0.5
            y_pred = decision_values < 0;
        else
            y_pred = temp_pred;
        end
    else
        y_pred = temp_pred;
    end
    
    % 确保输出是列向量
    y_pred = y_pred(:);
    y_scores = y_scores(:);
    
end

% SMO算法中的takeStep函数
function alpha_changed = takeStep(i1, X, y, K, error_cache, alpha, b, C, tol)
    alpha_changed = 0;
    
    % 获取第一个样本的信息
    y1 = y(i1);
    alpha1 = alpha(i1);
    E1 = computeError(i1, alpha, y, K, b);
    error_cache(i1) = E1;
    
    % 更严格的KKT条件检查
    % 对于alpha_i接近边界的值，使用较小的容差
    if alpha1 < C && alpha1 > 0
        % 内部点，要求y_i*E_i接近0
        if abs(y1 * E1) > 2 * tol
            proceed = true;
        else
            proceed = false;
        end
    else
        % 边界点，检查对应的KKT条件
        if (alpha1 >= C && y1 * E1 > -tol) || (alpha1 <= 0 && y1 * E1 < tol)
            % 满足KKT条件
            proceed = false;
        else
            % 不满足KKT条件
            proceed = true;
        end
    end
    
    if proceed
        % 选择第二个变量i2
        [i2, E2] = selectSecondAlpha(i1, E1, error_cache, length(y));
        
        % 获取第二个样本的信息
        y2 = y(i2);
        alpha2 = alpha(i2);
        error_cache(i2) = E2;
        
        % 保存旧的alpha值
        alpha1_old = alpha1;
        alpha2_old = alpha2;
        
        % 计算上下界
        if y1 == y2
            L = max(0, alpha2 + alpha1 - C);
            H = min(C, alpha2 + alpha1);
        else
            L = max(0, alpha2 - alpha1);
            H = min(C, C + alpha2 - alpha1);
        end
        
        if L == H
            % 上下界相等，无法更新
            return;
        end
        
        % 计算eta
        eta = 2 * K(i1,i2) - K(i1,i1) - K(i2,i2);
        
        % 如果eta >= 0，我们需要使用牛顿法的另一种形式
        if eta >= 0
            % 使用负梯度方向而不是二阶导数
            f1 = y1 * (E1 + b) - alpha1 * K(i1,i1) - alpha2 * K(i1,i2) * y1 * y2;
            f2 = y2 * (E2 + b) - alpha1 * K(i1,i2) * y1 * y2 - alpha2 * K(i2,i2);
            L_obj = f1 * y1;
            H_obj = f1 * y1;
            
            if y1 == y2
                L_obj = f1 * y1 + (L - alpha2_old) * (f1 - f2);
                H_obj = f1 * y1 + (H - alpha2_old) * (f1 - f2);
            else
                L_obj = f1 * y1 + (L - alpha2_old) * (f2 - f1);
                H_obj = f1 * y1 + (H - alpha2_old) * (f2 - f1);
            end
            
            if L_obj < H_obj - 1e-3
                alpha(i2) = L;
            elseif L_obj > H_obj + 1e-3
                alpha(i2) = H;
            else
                alpha(i2) = alpha2_old;
            end
        else
            % 正常情况，使用二阶导数更新
            alpha(i2) = alpha2 - (y2 * (E1 - E2)) / eta;
            
            % 裁剪alpha2到[L, H]范围
            alpha(i2) = max(L, min(H, alpha(i2)));
        end
        
        % 检查是否有足够的变化
        if abs(alpha(i2) - alpha2_old) < 1e-5
            return;
        end
        
        % 更新alpha1
        alpha(i1) = alpha1 + y1 * y2 * (alpha2_old - alpha(i2));
        
        % 更新阈值b 
        % 计算新的b值
        b_old = b;
        
        if alpha(i1) > 0 && alpha(i1) < C
            % alpha1在边界内，使用它计算b
            sum_alpha_y_K = 0;
            for j = find(alpha > 0)'
                sum_alpha_y_K = sum_alpha_y_K + alpha(j) * y(j) * K(j,i1);
            end
            b = y(i1) - sum_alpha_y_K;
        elseif alpha(i2) > 0 && alpha(i2) < C
            % alpha2在边界内，使用它计算b
            sum_alpha_y_K = 0;
            for j = find(alpha > 0)'
                sum_alpha_y_K = sum_alpha_y_K + alpha(j) * y(j) * K(j,i2);
            end
            b = y(i2) - sum_alpha_y_K;
        else
            % 两者都在边界上，使用平均
            sum_alpha_y_K1 = 0;
            sum_alpha_y_K2 = 0;
            for j = find(alpha > 0)'
                sum_alpha_y_K1 = sum_alpha_y_K1 + alpha(j) * y(j) * K(j,i1);
                sum_alpha_y_K2 = sum_alpha_y_K2 + alpha(j) * y(j) * K(j,i2);
            end
            b = (y(i1) - sum_alpha_y_K1 + y(i2) - sum_alpha_y_K2) / 2;
        end
        
        % 更新错误缓存 - 更高效的更新方式
        % 只更新活动样本的错误缓存
        active_indices = find(alpha > 0);
        for i = active_indices'
            error_cache(i) = computeError(i, alpha, y, K, b);
        end
        
        alpha_changed = 1;
    end
end

% 选择第二个alpha的辅助函数
function [i2, E2] = selectSecondAlpha(i1, E1, error_cache, n_samples)
    if any(error_cache ~= 0)
        % 启发式选择，选择使|E1 - E2|最大的i2，排除i1
        temp_error = error_cache;
        temp_error(i1) = -inf; % 排除i1
        [~, i2] = max(abs(E1 - temp_error));
        E2 = error_cache(i2);
    else
        % 如果错误缓存全为0，随机选择一个不同的i2
        i2 = randi(n_samples);
        while i2 == i1
            i2 = randi(n_samples);
        end
        E2 = 0; % 初始错误设为0
    end
end

% 计算单个样本的误差
function E = computeError(i, alpha, y, K, b)
    E = b;
    active_indices = find(alpha > 0);
    E = E + sum(alpha(active_indices) .* y(active_indices) .* K(active_indices, i));
    E = E - y(i);
end

% 计算核矩阵
function K = computeKernelMatrix(X1, X2, kernel_type)
    n1 = size(X1, 1);
    n2 = size(X2, 1);
    K = zeros(n1, n2);
    
    for i = 1:n1
        for j = 1:n2
            K(i,j) = computeKernel(X1(i,:), X2(j,:), kernel_type);
        end
    end
end

% 核函数计算
function k_val = computeKernel(x1, x2, kernel_type)
    switch lower(kernel_type)
        case 'linear'
            k_val = x1 * x2';
        case 'rbf'
            sigma = 1.0;
            k_val = exp(-sum((x1 - x2).^2) / (2 * sigma^2));
        case 'polynomial'
            degree = 3;
            gamma = 1.0;
            coef0 = 0;
            k_val = (gamma * x1 * x2' + coef0)^degree;
        otherwise
            error('不支持的核函数类型: %s', kernel_type);
    end
end

% 基本逻辑回归算法实现
function [y_pred, y_scores, model] = logisticRegression(X_train, y_train, X_test, lambda, learning_rate, max_iter)
    % 参数默认值
    if nargin < 3
        error('需要至少提供训练数据、标签和测试数据');
    end
    if nargin < 4 || isempty(lambda)
        lambda = 0; % 默认不使用正则化
    end
    if nargin < 5 || isempty(learning_rate)
        learning_rate = 0.01; % 学习率
    end
    if nargin < 6 || isempty(max_iter)
        max_iter = 500; % 最大迭代次数
    end
    
    % 确保标签是列向量
    y_train = y_train(:);
    
    % 获取特征数和样本数
    n_samples = size(X_train, 1);
    n_features = size(X_train, 2);
    
    % 添加偏置项
    X_train_bias = [ones(n_samples, 1), X_train];
    X_test_bias = [ones(size(X_test, 1), 1), X_test];
    
    % 初始化权重（随机初始化）
    theta = zeros(n_features + 1, 1);
    
    % 简单梯度下降训练
    for iter = 1:max_iter
        % 计算预测概率
        z = X_train_bias * theta;
        h = 1 ./ (1 + exp(-z));
        
        % 计算梯度
        gradient = (X_train_bias' * (h - y_train)) / n_samples;
        
        % 添加L2正则化项
        if lambda > 0
            gradient(2:end) = gradient(2:end) + (lambda / n_samples) * theta(2:end);
        end
        
        % 使用简单梯度下降更新权重
        theta = theta - learning_rate * gradient;

    end
    
    % 构建模型
    model.theta = theta;
    model.lambda = lambda;
    model.learning_rate = learning_rate;
    
    % 预测测试集
    z_test = X_test_bias * theta;
    y_scores = 1 ./ (1 + exp(-z_test));
    
    % 预测类别
    y_pred = y_scores > 0.5;
    
    % 确保输出是列向量
    y_pred = y_pred(:);
    y_scores = y_scores(:);

end

% 计算AUC值的函数
function auc = calculateAUC(actualLabels, predictedScores)
    % 确保输入是列向量
    actualLabels = actualLabels(:);
    predictedScores = predictedScores(:);
    
    % 检查数据维度是否匹配
    if length(actualLabels) ~= length(predictedScores)
        error('标签和预测分数维度不匹配');
    end
    
    % 计算正例和负例的数量
    posCount = sum(actualLabels);
    negCount = length(actualLabels) - posCount;
    
    % 特殊情况处理
    if posCount == 0 || negCount == 0
        auc = 0.5;  % 所有样本都是同一类别
        return;
    end
    
    % 方法1：尝试使用升序排序
    [~, idx] = sort(predictedScores);  % 按预测分数升序排序
    sortedLabels = actualLabels(idx);
    
    % 计算正例的排名和
    posRankSum = 0;
    for i = 1:length(sortedLabels)
        if sortedLabels(i) == 1  % 正例 (恶性)
            posRankSum = posRankSum + i;
        end
    end
    
    % 使用标准AUC计算公式
    auc = (posRankSum - posCount*(posCount + 1)/2) / (posCount * negCount);
    
    % 如果AUC太小，可能是预测分数方向问题，尝试反转
    if auc < 0.5
        auc = 1 - auc;
    end
    
    % 确保AUC在0-1范围内
    auc = max(0, min(1, auc));
end

% 计算召回率(Recall)的函数
function recall = calculateRecall(actualLabels, predictedLabels)
    % 计算召回率 (TPR = TP / (TP + FN))
    % actualLabels: 实际标签 (0/1)
    % predictedLabels: 预测标签 (0/1)
    
    % 确保输入是列向量
    actualLabels = actualLabels(:);
    predictedLabels = predictedLabels(:);
    
    % 检查数据维度是否匹配
    if length(actualLabels) ~= length(predictedLabels)
        error('实际标签和预测标签维度不匹配');
    end
    
    % 计算真阳性(TP)和假阴性(FN)
    TP = sum((actualLabels == 1) & (predictedLabels == 1));  % 实际为正且预测为正
    FN = sum((actualLabels == 1) & (predictedLabels == 0));  % 实际为正但预测为负
    
    % 计算召回率
    if (TP + FN) > 0
        recall = TP / (TP + FN);
    else
        % 特殊情况：没有正例，返回1.0表示所有正例都被正确预测
        recall = 1.0;
    end
    
    % 确保召回率在0-1范围内
    recall = max(0, min(1, recall));
end

% 计算精确率(Precision)的函数
function precision = calculatePrecision(actualLabels, predictedLabels)
    % 计算精确率 (PPV = TP / (TP + FP))
    % actualLabels: 实际标签 (0/1)
    % predictedLabels: 预测标签 (0/1)
    
    % 确保输入是列向量
    actualLabels = actualLabels(:);
    predictedLabels = predictedLabels(:);
    
    % 检查数据维度是否匹配
    if length(actualLabels) ~= length(predictedLabels)
        error('实际标签和预测标签维度不匹配');
    end
    
    % 计算真阳性(TP)和假阳性(FP)
    TP = sum((actualLabels == 1) & (predictedLabels == 1));  % 实际为正且预测为正
    FP = sum((actualLabels == 0) & (predictedLabels == 1));  % 实际为负但预测为正
    
    % 计算精确率
    if (TP + FP) > 0
        precision = TP / (TP + FP);
    else
        % 特殊情况：没有预测为正例，返回1.0表示所有正预测都正确
        precision = 1.0;
    end
    
    % 确保精确率在0-1范围内
    precision = max(0, min(1, precision));
end

% 计算F1评分的函数
function f1 = calculateF1Score(actualLabels, predictedLabels)
    % 计算F1评分 (F1 = 2 * (Precision * Recall) / (Precision + Recall))
    % actualLabels: 实际标签 (0/1)
    % predictedLabels: 预测标签 (0/1)
    
    % 计算精确率和召回率
    precision = calculatePrecision(actualLabels, predictedLabels);
    recall = calculateRecall(actualLabels, predictedLabels);
    
    % 计算F1评分
    if (precision + recall) > 0
        f1 = 2 * (precision * recall) / (precision + recall);
    else
        % 特殊情况：精确率和召回率都为0，返回0
        f1 = 0;
    end
    
    % 确保F1评分在0-1范围内
    f1 = max(0, min(1, f1));
end

% 主函数
function main()
    % 声明全局变量，以便画图函数访问
    global accBSSAF accXGBoost accSVM accLogReg;  % 准确率
    global aucBSSAF aucXGBoost aucSVM aucLogReg;  % AUC
    global recallBSSAF recallXGBoost recallSVM recallLogReg;  % 召回率
    global sensitivityBSSAF sensitivityXGBoost sensitivitySVM sensitivityLogReg;  % 灵敏度
    global f1BSSAF f1XGBoost f1SVM f1LogReg;  % F1评分

    fprintf('============================================\n');
    fprintf('        乳腺癌诊断算法性能比较系统          \n');
    fprintf('============================================\n');

    % 数据加载与预处理
    fprintf('正在加载数据集...\n');

    try
        % 直接使用本地已有的wdbc.data文件
        fprintf('使用本地已存在的wdbc.data文件...\n');
        
        % 使用textscan读取CSV格式数据
        fid = fopen('wdbc.data', 'r');
        if fid == -1
            error('无法打开数据文件wdbc.data');
        end
        
        % 直接读取数据，根据UCI乳腺癌数据集格式：
        % 第一列：ID (字符串)
        % 第二列：诊断结果(M/B) (字符串)
        % 第3-32列：30个特征值 (浮点数)
        formatSpec = '%s %s';
        for i = 3:32
            formatSpec = [formatSpec, ' %f'];
        end
        
        data = textscan(fid, formatSpec, 'Delimiter', ',', 'ReturnOnError', false);
        fclose(fid);
        
        % 数据验证
        if isempty(data) || length(data) < 2
            error('无法从数据文件中读取有效数据');
        end
        
        % 提取标签（第二列是M/B诊断结果）
        labels = data{2};
        
        % 提取特征（第3-32列共30个特征）
        featureCells = {};
        for i = 3:length(data)
            if ~isempty(data{i})
                featureCells{end+1} = data{i};  %#ok<AGROW>
            end
        end
        
        % 转换特征为矩阵
        features = cell2mat(featureCells);
        
        % 验证数据维度
        fprintf('数据加载成功！\n');
        fprintf('样本数量: %d\n', length(labels));
        fprintf('特征维度: %d\n', length(featureCells));
        
        % 统计标签分布
        if ~isempty(labels)
            benignCount = sum(strcmp(labels, 'B'));
            malignantCount = sum(strcmp(labels, 'M'));
            fprintf('良性样本数(B): %d\n', benignCount);
        fprintf('恶性样本数(M): %d\n', malignantCount);
            labels = categorical(labels);
        else
            error('标签数据为空');
        end
        
        % 数据标准化
        if length(featureCells) > 0 && length(labels) > 0
            % 确保特征矩阵维度正确
            if size(features, 1) ~= length(labels)
                features = features';
            end
            
            % 执行z-score标准化
            for i = 1:size(features, 2)
                colMean = mean(features(:, i));
                colStd = std(features(:, i));
                if colStd > 0
                    features(:, i) = (features(:, i) - colMean) / colStd;
                end
            end
            fprintf('数据标准化完成\n');
        else
            error('特征数据或标签数据无效');
        end
        
        % 数据集划分
        fprintf('\n正在划分数据集...\n');
        rng(2025);  % 设置随机数种子确保结果可复现
        
        % 计算样本总数和训练集大小
        totalSamples = length(labels);
        trainSize = round(totalSamples * 0.7);
        
        % 随机生成索引
        indices = randperm(totalSamples);
        trainIndices = indices(1:trainSize);
        testIndices = indices(trainSize+1:end);
        
        % 划分数据集
        trainFeatures = features(trainIndices, :);
        trainLabels = labels(trainIndices);
        testFeatures = features(testIndices, :);
        testLabels = labels(testIndices);
        
        fprintf('训练集大小: %d\n', length(trainLabels));
    fprintf('测试集大小: %d\n', length(testLabels));
        
        % 检查trainLabels和testLabels的结构
        fprintf('标签数据结构调试:\n');
    fprintf('trainLabels 类型: %s, 大小: %d x %d\n', class(trainLabels), size(trainLabels,1), size(trainLabels,2));
    fprintf('testLabels 类型: %s, 大小: %d x %d\n', class(testLabels), size(testLabels,1), size(testLabels,2));
        
        % 创建结果变量，预设维度以避免维度问题
        trainLabelsNum = zeros(size(trainLabels,1), 1);
        testLabelsNum = zeros(size(testLabels,1), 1);
        
        % 处理训练标签
        if iscategorical(trainLabels)
            % 对于categorical类型，先转换为字符串
            trainLabelsStr = cellstr(trainLabels);
            for i = 1:length(trainLabelsStr)
                trainLabelsNum(i) = strcmp(trainLabelsStr{i}, 'M');
            end
        elseif iscell(trainLabels)
            % 处理单元格数组情况
            for i = 1:length(trainLabels)
                if ischar(trainLabels{i}) || isstring(trainLabels{i})
                    trainLabelsNum(i) = strcmp(trainLabels{i}, 'M');
                end
            end
        else
            % 处理其他类型
            fprintf('警告: 训练标签类型不明确，尝试直接比较\n');
            trainLabelsChar = char(trainLabels);
            for i = 1:size(trainLabelsChar,1)
                trainLabelsNum(i) = strcmp(trainLabelsChar(i,:), 'M');
            end
        end
        
        % 处理测试标签
        if iscategorical(testLabels)
            % 对于categorical类型，先转换为字符串
            testLabelsStr = cellstr(testLabels);
            for i = 1:length(testLabelsStr)
                testLabelsNum(i) = strcmp(testLabelsStr{i}, 'M');
            end
        elseif iscell(testLabels)
            % 处理单元格数组情况
            for i = 1:length(testLabels)
                if ischar(testLabels{i}) || isstring(testLabels{i})
                    testLabelsNum(i) = strcmp(testLabels{i}, 'M');
                end
            end
        else
            % 处理其他类型
            fprintf('警告: 测试标签类型不明确，尝试直接比较\n');
            testLabelsChar = char(testLabels);
            for i = 1:size(testLabelsChar,1)
                testLabelsNum(i) = strcmp(testLabelsChar(i,:), 'M');
            end
        end
        
        % 添加一些调试信息，验证数据维度
        fprintf('训练特征维度: %d x %d\n', size(trainFeatures,1), size(trainFeatures,2));
    fprintf('测试特征维度: %d x %d\n', size(testFeatures,1), size(testFeatures,2));
    fprintf('训练标签数量: %d\n', length(trainLabelsNum));
    fprintf('测试标签数量: %d\n', length(testLabelsNum));
        
        % 算法1：BSSAF神经网络
        fprintf('\n正在训练BSSAF神经网络...\n');
        try
            % 设置BSSAF神经网络参数
            hiddenSize = 48;  % 增加隐藏层神经元以提高模型表达能力
            epochs = 300;     % 增加训练轮数以获得更好的收敛
            learning_rate = 0.002;  % 降低学习率以获得更稳定的训练
            
            % 训练BSSAF神经网络
            [bssafPred, bssafScores] = bssafClassifier(trainFeatures, trainLabelsNum, testFeatures, hiddenSize, epochs, learning_rate);
            
            % 计算准确率
            correct = sum(bssafPred == testLabelsNum);
            total = length(testLabelsNum);
            accBSSAF = correct / total;
            
            % 计算AUC
            aucBSSAF = calculateAUC(testLabelsNum, bssafScores);
            
            % 计算召回率
            recallBSSAF = calculateRecall(testLabelsNum, bssafPred);
            
            % 计算灵敏度
            sensitivityBSSAF = recallBSSAF;  % 在二分类中，灵敏度=召回率=TP/(TP+FN)
            
            % 计算精确率和F1评分
            precisionBSSAF = calculatePrecision(testLabelsNum, bssafPred);
            f1BSSAF = calculateF1Score(testLabelsNum, bssafPred);
            
            fprintf('BSSAF训练完成！准确率: %.4f (%d/%d), AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accBSSAF, correct, total, aucBSSAF, recallBSSAF, sensitivityBSSAF, f1BSSAF);
        catch ME
            fprintf('错误：BSSAF训练失败！\n');
            fprintf('错误信息: %s\n', ME.message);
            accBSSAF = NaN;
            aucBSSAF = NaN;
            recallBSSAF = NaN;
            sensitivityBSSAF = NaN;
            precisionBSSAF = NaN;
            f1BSSAF = NaN;
        end
        
        % 算法2：XGBoost
        fprintf('\n正在训练XGBoost...\n');
        try
            % 设置XGBoost参数
            num_trees = 50;
            max_depth = 3;
            learning_rate = 0.1;
            
            % 训练XGBoost模型
            [xgbPred, xgbScores] = xgboost(trainFeatures, trainLabelsNum, testFeatures, num_trees, max_depth, learning_rate);
            
            % 计算准确率
            correct = sum(xgbPred == testLabelsNum);
            total = length(testLabelsNum);
            accXGBoost = correct / total;
            
            % 计算AUC
            aucXGBoost = calculateAUC(testLabelsNum, xgbScores);
            
            % 计算召回率
            recallXGBoost = calculateRecall(testLabelsNum, xgbPred);
            
            % 计算灵敏度
            sensitivityXGBoost = recallXGBoost;  % 在二分类中，灵敏度=召回率=TP/(TP+FN)
            
            % 计算精确率和F1评分
            precisionXGBoost = calculatePrecision(testLabelsNum, xgbPred);
            f1XGBoost = calculateF1Score(testLabelsNum, xgbPred);
            
            fprintf('XGBoost训练完成！准确率: %.4f (%d/%d), AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accXGBoost, correct, total, aucXGBoost, recallXGBoost, sensitivityXGBoost, f1XGBoost);
        catch ME
            fprintf('错误：XGBoost训练失败！\n');
            fprintf('错误信息: %s\n', ME.message);
            accXGBoost = NaN;
            aucXGBoost = NaN;
            recallXGBoost = NaN;
            sensitivityXGBoost = NaN;
            precisionXGBoost = NaN;
            f1XGBoost = NaN;
        end
        
        % 算法3：SVM
        fprintf('\n正在训练SVM...\n');
        try
            % 设置SVM参数
            C = 1.0;  % 正则化参数
            kernel = 'linear';  % 核函数类型
            tol = 1e-3;  % 容差
            max_iter = 1000;  % 最大迭代次数
            
            % 训练SVM模型
            [svmPred, svmScores] = svm(trainFeatures, trainLabelsNum, testFeatures, C, kernel, tol, max_iter);
            
            % 计算准确率
            correct = sum(svmPred == testLabelsNum);
            total = length(testLabelsNum);
            accSVM = correct / total;
            
            % 计算AUC
            aucSVM = calculateAUC(testLabelsNum, svmScores);
            
            % 计算召回率
            recallSVM = calculateRecall(testLabelsNum, svmPred);
            
            % 计算灵敏度
            sensitivitySVM = recallSVM;  % 在二分类中，灵敏度=召回率=TP/(TP+FN)
            
            % 计算精确率和F1评分
            precisionSVM = calculatePrecision(testLabelsNum, svmPred);
            f1SVM = calculateF1Score(testLabelsNum, svmPred);
            
            fprintf('SVM训练完成！准确率: %.4f (%d/%d), AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accSVM, correct, total, aucSVM, recallSVM, sensitivitySVM, f1SVM);
        catch ME
            fprintf('错误：SVM训练失败！\n');
            fprintf('错误信息: %s\n', ME.message);
            accSVM = NaN;
            aucSVM = NaN;
            recallSVM = NaN;
            sensitivitySVM = NaN;
            precisionSVM = NaN;
            f1SVM = NaN;
        end
        
        % 算法4：逻辑回归
        fprintf('\n正在训练逻辑回归...\n');
        try
            % 设置逻辑回归参数
            lambda = 0;  % 正则化参数（默认不使用）
            learning_rate = 0.01;  % 学习率
            max_iter = 500;  % 最大迭代次数
            
            % 训练逻辑回归模型
            [logRegPred, logRegScores] = logisticRegression(trainFeatures, trainLabelsNum, testFeatures, lambda, learning_rate, max_iter);
            
            % 计算准确率
            correct = sum(logRegPred == testLabelsNum);
            total = length(testLabelsNum);
            accLogReg = correct / total;
            
            % 计算AUC
            aucLogReg = calculateAUC(testLabelsNum, logRegScores);
            
            % 计算召回率
            recallLogReg = calculateRecall(testLabelsNum, logRegPred);
            
            % 计算灵敏度
            sensitivityLogReg = recallLogReg;  % 在二分类中，灵敏度=召回率=TP/(TP+FN)
            
            % 计算精确率和F1评分
            precisionLogReg = calculatePrecision(testLabelsNum, logRegPred);
            f1LogReg = calculateF1Score(testLabelsNum, logRegPred);
            
            fprintf('逻辑回归训练完成！准确率: %.4f (%d/%d), AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accLogReg, correct, total, aucLogReg, recallLogReg, sensitivityLogReg, f1LogReg);
        catch ME
            fprintf('错误：逻辑回归训练失败！\n');
            fprintf('错误信息: %s\n', ME.message);
            accLogReg = NaN;
            aucLogReg = NaN;
            recallLogReg = NaN;
            sensitivityLogReg = NaN;
            precisionLogReg = NaN;
            f1LogReg = NaN;
        end
        
        % 性能比较
        fprintf('\n============================================\n');
    fprintf('               模型性能指标               \n');
    fprintf('============================================\n');
        
        if ~isnan(accBSSAF)
            fprintf('BSSAF神经网络准确率: %.4f, AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accBSSAF, aucBSSAF, recallBSSAF, sensitivityBSSAF, f1BSSAF);
        end
        if ~isnan(accXGBoost)
            fprintf('XGBoost准确率: %.4f, AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accXGBoost, aucXGBoost, recallXGBoost, sensitivityXGBoost, f1XGBoost);
        end
        if ~isnan(accSVM)
            fprintf('SVM准确率: %.4f, AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accSVM, aucSVM, recallSVM, sensitivitySVM, f1SVM);
        end
        if ~isnan(accLogReg)
            fprintf('逻辑回归准确率: %.4f, AUC: %.4f, 召回率: %.4f, 灵敏度: %.4f, F1评分: %.4f\n', accLogReg, aucLogReg, recallLogReg, sensitivityLogReg, f1LogReg);
        end
        
        % 找出最佳算法（基于准确率）
        validAccs = [accBSSAF, accXGBoost, accSVM, accLogReg];
        validAccs = validAccs(~isnan(validAccs));
        validRecalls = [recallBSSAF, recallXGBoost, recallSVM, recallLogReg];
        validRecalls = validRecalls(~isnan(validRecalls));
        validF1Scores = [f1BSSAF, f1XGBoost, f1SVM, f1LogReg];
        validF1Scores = validF1Scores(~isnan(validF1Scores));
        validIdxs = find(~isnan([accBSSAF, accXGBoost, accSVM, accLogReg]));
        
        if ~isempty(validAccs)
            [maxAcc, bestIdx] = max(validAccs);
            bestAlgorithms = {'BSSAF神经网络', 'XGBoost', 'SVM', '逻辑回归'};
            fprintf('\n最佳算法(准确率): %s (准确率: %.4f)\n', bestAlgorithms{validIdxs(bestIdx)}, maxAcc);
            
            % 找出最佳算法（基于AUC）
            validAUCs = [aucBSSAF, aucXGBoost, aucSVM, aucLogReg];
            validAUCs = validAUCs(~isnan(validAUCs));
            validAUCIdxs = find(~isnan([aucBSSAF, aucXGBoost, aucSVM, aucLogReg]));
            
            if ~isempty(validAUCs)
                [maxAUC, bestAUCIdx] = max(validAUCs);
                fprintf('最佳算法(AUC): %s (AUC: %.4f)\n', bestAlgorithms{validAUCIdxs(bestAUCIdx)}, maxAUC);
            end
            
            % 找出最佳算法（基于召回率）
            if ~isempty(validRecalls)
                [maxRecall, bestRecallIdx] = max(validRecalls);
                validRecallIdxs = find(~isnan([recallBSSAF, recallXGBoost, recallSVM, recallLogReg]));
                fprintf('最佳算法(召回率): %s (召回率: %.4f)\n', bestAlgorithms{validRecallIdxs(bestRecallIdx)}, maxRecall);
            end
            
            % 找出最佳算法（基于灵敏度）
            if ~isempty(validRecalls)
                [maxSensitivity, bestSensitivityIdx] = max(validRecalls);
                validSensitivityIdxs = find(~isnan([sensitivityBSSAF, sensitivityXGBoost, sensitivitySVM, sensitivityLogReg]));
                fprintf('最佳算法(灵敏度): %s (灵敏度: %.4f)\n', bestAlgorithms{validSensitivityIdxs(bestSensitivityIdx)}, maxSensitivity);
            end
            
            % 找出最佳算法（基于F1评分）
            if ~isempty(validF1Scores)
                [maxF1, bestF1Idx] = max(validF1Scores);
                validF1Idxs = find(~isnan([f1BSSAF, f1XGBoost, f1SVM, f1LogReg]));
                fprintf('最佳算法(F1评分): %s (F1评分: %.4f)\n', bestAlgorithms{validF1Idxs(bestF1Idx)}, maxF1);
            end
        end
        
        fprintf('============================================\n');
        
        
        fprintf('\n开始生成算法性能对比图表...\n');
        
        % 调用画图函数生成比较图表
        plotAlgorithmComparison();
        
        fprintf('图形生成完成！\n');
        fprintf('\n程序执行完成！\n');
        
    catch ME
        fprintf('错误：程序执行失败！\n');
    fprintf('错误信息: %s\n', ME.message);
    end
end


% 运行主函数
main();

% 画图函数
function plotAlgorithmComparison()
    % 使用全局变量获取所有算法的指标数据
    global accBSSAF accXGBoost accSVM accLogReg;  % 准确率
    global aucBSSAF aucXGBoost aucSVM aucLogReg;  % AUC
    global recallBSSAF recallXGBoost recallSVM recallLogReg;  % 召回率
    global sensitivityBSSAF sensitivityXGBoost sensitivitySVM sensitivityLogReg;  % 灵敏度
    global f1BSSAF f1XGBoost f1SVM f1LogReg;  % F1评分
    
    % 准备所有指标数据
    accuracyValues = [accBSSAF, accXGBoost, accSVM, accLogReg];
    aucValues = [aucBSSAF, aucXGBoost, aucSVM, aucLogReg];
    recallValues = [recallBSSAF, recallXGBoost, recallSVM, recallLogReg];
    sensitivityValues = [sensitivityBSSAF, sensitivityXGBoost, sensitivitySVM, sensitivityLogReg];
    f1Values = [f1BSSAF, f1XGBoost, f1SVM, f1LogReg];
    % 算法名称
    algorithms = {'BSSAF', 'XGBoost', 'SVM', '逻辑回归'};
    
    % 创建准确率对比图
    figure('Name', '算法准确率对比', 'Position', [100, 100, 800, 600]);
    bar(accuracyValues, 'FaceColor', [0.2, 0.5, 0.8]);
    hold on;
    
    % 添加数据标签
    for i = 1:length(accuracyValues)
        if ~isnan(accuracyValues(i))
            text(i, accuracyValues(i) + 0.01, sprintf('%.4f', accuracyValues(i)), 'HorizontalAlignment', 'center');
        end
    end
    
    % 设置坐标轴和标题
    set(gca, 'XTickLabel', algorithms, 'FontSize', 12);
    ylim([0.8, 1]);
    title('不同算法的准确率对比', 'FontSize', 14);
    xlabel('算法', 'FontSize', 12);
    ylabel('准确率', 'FontSize', 12);
    grid on;
    hold off;

    
    % 创建AUC对比图
    figure('Name', '算法AUC对比', 'Position', [200, 200, 800, 600]);
    bar(aucValues, 'FaceColor', [0.5, 0.7, 0.3]);
    hold on;
    
    % 添加数据标签
    for i = 1:length(aucValues)
        if ~isnan(aucValues(i))
            text(i, aucValues(i) + 0.01, sprintf('%.4f', aucValues(i)), 'HorizontalAlignment', 'center');
        end
    end
    
    % 设置坐标轴和标题
    set(gca, 'XTickLabel', algorithms, 'FontSize', 12);
    ylim([0.9, 1]);
    title('不同算法的AUC对比', 'FontSize', 14);
    xlabel('算法', 'FontSize', 12);
    ylabel('AUC', 'FontSize', 12);
    grid on;
    hold off;

    % 创建召回率和灵敏度对比图
    figure('Name', '算法召回率和灵敏度对比', 'Position', [300, 300, 800, 600]);
    
    % 准备数据
    bar_data = [recallValues; sensitivityValues];
    x_pos = 1:length(algorithms);
    
    % 创建分组柱状图
    bar_width = 0.35;
    bar(x_pos - bar_width/2, bar_data(1,:), bar_width, 'FaceColor', [0.8, 0.4, 0.2]);
    hold on;
    bar(x_pos + bar_width/2, bar_data(2,:), bar_width, 'FaceColor', [0.4, 0.6, 0.8]);
    
    % 添加数据标签
    for i = 1:length(algorithms)
        if ~isnan(bar_data(1,i))
            text(i - bar_width/2, bar_data(1,i) + 0.01, sprintf('%.4f', bar_data(1,i)), 'HorizontalAlignment', 'center');
        end
        if ~isnan(bar_data(2,i))
            text(i + bar_width/2, bar_data(2,i) + 0.01, sprintf('%.4f', bar_data(2,i)), 'HorizontalAlignment', 'center');
        end
    end
    
    % 设置坐标轴和标题
    set(gca, 'XTick', x_pos, 'XTickLabel', algorithms, 'FontSize', 12);
    ylim([0.8, 1]);
    title('不同算法的召回率和灵敏度对比', 'FontSize', 14);
    xlabel('算法', 'FontSize', 12);
    ylabel('值', 'FontSize', 12);
    
    % 添加图例
    legend('召回率', '灵敏度', 'Location', 'best');
    
    grid on;
    hold off;
    
    % 创建F1评分对比图
    figure('Name', '算法F1评分对比', 'Position', [400, 400, 800, 600]);
    bar(f1Values, 'FaceColor', [0.6, 0.3, 0.6]);
    hold on;
    
    % 添加数据标签
    for i = 1:length(f1Values)
        if ~isnan(f1Values(i))
            text(i, f1Values(i) + 0.01, sprintf('%.4f', f1Values(i)), 'HorizontalAlignment', 'center');
        end
    end
    
    % 设置坐标轴和标题
    set(gca, 'XTickLabel', algorithms, 'FontSize', 12);
    ylim([0.8, 1]);
    title('不同算法的F1评分对比', 'FontSize', 14);
    xlabel('算法', 'FontSize', 12);
    ylabel('F1评分', 'FontSize', 12);
    grid on;
    hold off;

end
